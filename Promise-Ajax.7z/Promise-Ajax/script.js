"use strict"
// Asinchroninio kodo pavyzdys

// Pakvieskime funkciją gaukTeksta(), kuri grąžins mums Promise
// Kai bus gautas tekstas, jį atspausdinsime ekrane
let paragrafas = document.querySelector("p");


// Asinchroninė užklausa, gali trukti ilgai, grąžina mums Promise objektą
gaukTeksta()
    .then(function(result){
        paragrafas.innerText = result;
    })
    .catch(function(error) {
        paragrafas.innerText = error;
    });


function gaukTeksta() {

    let promise = new Promise(function(resolve, reject){
        // executor 
        // ilgai trunkantis darbas
            setTimeout(function(){
                console.log("test 1");
                resolve("Darbas baigtas"); ///kuria pazada
                alert("test");
            }, 2000);
        });

    return promise;
}