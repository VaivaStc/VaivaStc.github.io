//Issaugoti h1 i kintamaji
let h1Element = document.body.firstElementChild;

console.log(h1Element.childNodes);

//universali query selector all funkcija. jai reikia paduoti reiksmes. tarp kabuciu realus css. 0 parodo, kuri elementa imam [].
let h1El = document.querySelectorAll(".My-Heading")[0];

console.log(h1El);

//pakeisti h1 teksta is javascripto
h1El.innerText = "Skaičiuotuvas";
h1El.style.fontStyle = "italic";
h1El.classList.add("main-header");

//issaugokite <input> elementa. surasti inputa
let inputEl = document.querySelector("input");
console.log(inputEl);
inputEl.placeholder = "Įveskite skaičių";

//sukurkite nauja <div> su klase .info
let infoEl = document.createElement("div");

//uzdeti klase
infoEl.className = "info info-text";

//Irasom div klase
infoEl.innerText = "Iveskite skaiciu ir paspaukite mygtuka, kad pakelti kvadratu";
infoEl.style.display = "none";
//iterpiame nauja div po formos elementu
let formEl = document.querySelector("form");
formEl.after(infoEl);

//ideti nauja mygtuka i forma
let newBtn = document.createElement("button");
newBtn.type = "button";
newBtn.innerText = "Informacija";

//registurojam event ant mygutko paspaudimo. pirmas parametras tipas, kokio ivykio klausosi, antras - ka daryti. cll-back funkcijos
newBtn.addEventListener("click", /*kelkKvadratu*/ /*defined anonimine funcija*/ function () {
    infoEl.style.display = "block";
});

formEl.appendChild(newBtn);

//padaryti, kad skaiciuokle skaiciuotu. Su elementais susieti funkcijas
    // 1. nuskaitom input value
    // 2. paskaiciuoti kvadratu x*x 
    //3. irasyti input value
function kelkKvadratu() {
    console.dir(inputEl);
    let newNumber = inputEl.value;
    let NewValue = newNumber*newNumber; 
    inputEl.value = NewValue;
 

}

/*
function kelkKvasratu () {*inputEl.value *= inputEl.value;}*/

