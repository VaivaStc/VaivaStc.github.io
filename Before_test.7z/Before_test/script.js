
function reverseString(string) {
    // logika
    let result = string.split('').reverse().join('');

    console.log(result);
}

// reverseString("labas"); // "sabal"

let weekday = ["Sekmadienis", "Pirmadienis", "Antradienis", "Treciadienis", "Ketvirtadienis", "Penktadienis", "etadienis", ];

let months = ["sausio", "vasario", "kovo", "baland˛io", "gegu˛es", "bir˛elio", "liepos", "rugpjucio", "rugsejo", "spalio", "lapkricio", "gruod˛io"];

function getDateText(pridekDienu) {
    let date = new Date();

    let savaitesDiena = weekday[date.getDay()]; //
    let menuo = date.getMonth();
    let diena = date.getDate();

    if (pridekDienu) {
        // sukurti nauja data prie esamos prideti 2 dienas
        let metai = date.getFullYear();

        let naujaData = new Date(metai, menuo, diena + +pridekDienu);
        
        savaitesDiena = weekday[naujaData.getDay()]; //
        menuo = naujaData.getMonth();
        diena = naujaData.getDate();
        
        console.log(`uz ${pridekDienu} dienu, bus ${savaitesDiena}, ${months[menuo]} ${diena} diena`);
        return;
    }
    
    console.log(`${savaitesDiena}, ${months[menuo]} ${diena} diena`);
}

getDateText();

let filtered = MOCK_DATA.filter(function(item){
    return item.country === "China" && item.email.slice (-4) === ".com"
});

let emails = filtered.map(function(item){
    return item.email;
});

/*
let emails = [];
for (let index = 0; index < MOCK_DATA.length; index++) {
    const element = MOCK_DATA[index];
    emails.push(element.email);
}

let emailsCom = [];
for (let index = 0; index < MOCK_DATA.length; index++) {
    const element = MOCK_DATA[index];
    if (element.email.slice (-4) === ".com")
    emailsCom.push(element.email);
}
*/