"use strict";

let app = new Vue({
    el: "#app",
    data: {
        albums: [],
        newAlbum: {
            artist: "",
            album: "",
            releaseDate: "",
            tags: "",
            image: "",
            searchText: "",
        }
    },
    methods: {
        getTags: function (text) {
            return text.split(",")
        },
        deleteAlbum: function () {
            // Trinam iš serverio
            fetch(serverName + "/albums/" + album.id, {
                method: "DELETE",
            }).then(function (response) {
                console.log("Albumas ištrintas");
            });
            //Trinam is duomenu
            let index = this.albums.indexOf(album);
            this.albums.splice(index, 1)
        },
        saveAlbum: function () {
            fetch(serverName + "/albums", {
                method: "POST",
                headers: { 'content-type': 'application/json' },
                body: JSON.stringify(this.newAlbum)
            }).then(function (response) {
                response.json()
                    .then(function (result) {
                        console.log("albumas issaugotas");
                        // Išsisaugom albumą į bendrą sąrašą
                    })
            })

            this.albums.push.push(this.newAlbum);
        }
    },
        processFile: function (event) {
        //TODO: prideti server sde paveiksliuko saugojima
        this.newAlbum.image = event.target.files[0] ? event.target.files[0].name : "";
    },
    computed: {
        filteredAlbums: function() {
            let filtered = this.albums.filter(function(item){
                let searchText = app.searchText.toLowerCase();
                let isArtistFound = item.artist.toLowerCase().indexOf(searchText) !== -1 ? true:false;
                let isAlbumFound = item.album.toLowerCase().indexOf(searchText) !== -1? true:false;

                if(isArtistFound || isAlbumFound ) {
                    return true;
                } 
                return false;
            });
            return filtered;
        }
    }
});

app.start();
