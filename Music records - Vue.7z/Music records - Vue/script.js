"use strict";

// Mygtukai
const searchBtn = document.querySelector(".btn-search");
const searchInput = document.querySelector(".search-input");

// Forma ir mygtukai
const formElement = document.querySelector("form");
const submitBtn = document.querySelector(".modal .modal-footer > .btn-primary");
const closeBtn = document.querySelector(".modal .modal-footer > .btn-default");

// Formos laukai
const artistInput = document.getElementById("artist");
const albumInput = document.getElementById("album");
const releaseDateInput = document.getElementById("releaseDate");
const imageInput = document.getElementById("image");
const tagsInput = document.getElementById("tags");

const albumListElement = document.querySelector(".album-list");
let allAlbums = [];

const serverName = "http://localhost:3044";


// Patikriname ar turime išsaugotą albumą localStorage
// Jei turime, tada atvaizduojame HTML'e
// if (localStorage.albums) {

    // duomenys iš localStorage
    // allAlbums = JSON.parse(localStorage.albums);


    // duomenys iš serverio
    fetch(serverName + "/albums")
        .then(function(response){
            response.json()
                .then(function(albums) {
                    // Išsisaugom visus albumus
                    app.albums = albums;

                    // Spausdinam į HTML
                    //renderAlbums(albums);
                });
        })

// }


// Registruojam mygtuko paspausimą ant "Pridėti"
submitBtn.addEventListener("click", saveAlbum);

// Funkcija, kuri saugo albumą
function saveAlbum() {
    let imageName = imageInput.files[0] ? imageInput.files[0].name : "";
    let tags = tagsInput.value.split(",");

    let album = {
        "artist": artistInput.value,
        "album": albumInput.value,
        "releaseDate": releaseDateInput.value,
        "tags": tags,
        "image": imageName
    };

    // Išsaugome albumą į localStorage

   

function renderAlbums(albums) {
    
    let resultHtml = "";

    // Išsisaugom kiekvieno albumo html
    albums.forEach(function(album) {

        let tagsHtml = getTagsHtml(album.tags);

        resultHtml += `

        `;
    });

    
    // Viena operacija - įrašau visą rezultatą
    albumListElement.innerHTML = resultHtml;
}


function searchAlbums(search) {

}




searchBtn.addEventListener("click", getFilteredAlbum);
    
function getFilteredAlbum() {
    let filteredAlbums = allAlbums.filter(function(item) {
            let searchText = searchInput.value.toLowerCase(); // "ac" paieska
            let artist = item.artist.toLowerCase(); // "acdc"
            let album = item.album.toLowerCase(); // "highway to hell"
            
            let isArtistFound = artist.indexOf(searchText) !== -1 ? true : false; // "acdc".indexOf("ac") -> 0
            let isAlbumFound = album.indexOf(searchText) !== -1 ? true : false; // // "highway to hell".indexOf("ac") -> -1

            if (isArtistFound || isAlbumFound) {
                return true;
            }
            
            return false;
    });
    renderAlbums(filteredAlbums);
}}