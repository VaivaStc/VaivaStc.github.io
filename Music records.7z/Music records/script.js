"use strict";
//Forma ir mygtukai
const artistInput = document.getElementById("artist");
const albumInput = document.getElementById("album");
const releaseDateInput = document.getElementById("releaseDate");
const imageInput = document.getElementById("image");

const albumListEle = document.querySelector(".album-list");


//Formos laukai
const formElement = document.querySelector("form");
const submitBtn = document.querySelector(".modal .modal-footer > .btn-primary");
const closeBtn = document.querySelector(".modal .modal-footer > .btn-default");

//Saugosim albumus
submitBtn.addEventListener("click", saveAlbum); 

function saveAlbum() {
    let imageName = imageInput.files[0] ? imageInput.files[0].name : "";
    let album = {
        "artist": artistInput.value,
        "album": albumInput.value, 
        "releaseDate": releaseDateInput.value,
        "image": imageName,
    };

    console.log("saugau albuma");
    localStorage.setItem("album", JSON.stringify(album));

    renderAlbums(album);
}

function renderAlbums(album) {

    albumListEle.innerHTML = `
<div class="album clearfix panel panel-default">
    <div class="panel-body">
        <img src="upload" alt="PICTURE" class="pull-left" width="150">
        <h3>${album.album}- ${album.artist} </h3>
        Date: ${album.releaseDate}
    </div>
</div>
`;
}



