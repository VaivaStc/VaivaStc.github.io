let prekesKaina = prompt("Įveskite prekės kainą, €");
let pristatymas = prompt("Ar bus reikalingas pristatymas į namus? (Taip/Ne)");
let pristatymoKaina = 20;
let suma = +prekesKaina + +pristatymoKaina;

if (pristatymas == "Ne") {
    document.write (`<p>Prekės kaina: ${ prekesKaina } €
    <p>Prekę galite atsiimti nemokamai Vilniuje adresu Gedimino pr. 1a</p>`);
} else {
    let miestas = prompt("Į kurį miestą reikės pristatyti?");
    if ((miestas != "Vilnius") || (prekesKaina <= 50)) {
        document.write (
        `<p>Prekės kaina : ${ prekesKaina } €</p>
        <p>Pristatymas:  ${ pristatymoKaina } €</p>
        <p>Iš viso: ${ suma } €</p>
        <p>Prekę pristatysime į ${ miestas } per 1-3 dienas.</p>`);
    } else document.write (
        `<p>Prekės kaina : ${ prekesKaina } €</p>
        <p>Prekę nemokamai pristatysime į ${ miestas }</p>
        <p>per 1-3 dienas.</p>
        `);
    }

