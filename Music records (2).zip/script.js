"use strict";

// Forma ir mygtukai
const formElement = document.querySelector("form");
const submitBtn = document.querySelector(".modal .modal-footer > .btn-primary");
const closeBtn = document.querySelector(".modal .modal-footer > .btn-default");

// Formos laukai
const artistInput = document.getElementById("artist");
const albumInput = document.getElementById("album");
const releaseDateInput = document.getElementById("releaseDate");
const imageInput = document.getElementById("image");

const albumListElement = document.querySelector(".album-list");

let allAlbums = [];


// Patikriname ar turime išsaugotą albumą localStorage
// Jei turime, tada atvaizduojame HTML'e
if (localStorage.albums) {
    let albums = JSON.parse(localStorage.albums);
    renderAlbums(albums);
}


// Registruojam mygtuko paspausimą ant "Pridėti"
submitBtn.addEventListener("click", saveAlbum);

// Funkcija, kuri saugo albumą
function saveAlbum() {
    let imageName = imageInput.files[0] ? imageInput.files[0].name : "";

    let album = {
        "artist": artistInput.value,
        "album": albumInput.value,
        "releaseDate": releaseDateInput.value,
        "image": imageName
    };

    allAlbums.push(album);

    // Išsaugome albumą į localStorage
    localStorage.setItem('albums', JSON.stringify(allAlbums));
    
    // Atvaizduojame albumą HTML'e
    renderAlbums(allAlbums);
}

function renderAlbums(albums) {
    let resultHtml = '';

    // Išsisaugom kiekvieno albumo html
    albums.forEach(function(album) {
        resultHtml += `
            <div class="album clearfix panel panel-default">
                <div class="panel-body">
                    <img src="upload/${album.image}" alt="" class="pull-left" width="150">
                    <h3>${album.artist} - ${album.album}</h3>
                    Date: ${album.releaseDate}
                </div>
            </div>
        `;
    });

    // Viena operacija - įrašau visą rezultatą
    albumListElement.innerHTML = resultHtml;
}

