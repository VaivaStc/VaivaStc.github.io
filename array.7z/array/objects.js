"use strict";
//naujas objektas
let vartotojas = {
    vardas : "Jonas",
    pavarde: "Jonaitis",
    amzius: 29,
    spausdinkVarda: function() {
        console.log(this.vardas + " " + this.pavarde);
    }
};


//prideti nauja savybe ir priskiri
vartotojas.pastas = "jonas@gmail.com";
vartotojas.telefonai = ["+370 654 548", "+370 664 555"];

console.log(vartotojas);

//Sukurkite funkcijas, kurios grąžintų:
//- šalių sąrašą <array>
//- vidutinį žmonių amžių <number>
//- tik žmones, kurie aktyvūs <array> [{}, {}]
//- atsitiktinį žmogų "Vardas Pavadė"

function getCountryList(personsList) {
    let countries = [];

    for(let index = 0; index < personsList.length; index++) {
        let person = personsList[index];
        countries.push(person.country);
    }
    return countries;
}

function getActiveUsers(personsList) {
    let UserList = []

    personsList.forEach(function(person){
        console.log(`${person.name} testing forach`)
    }); 
}
getActiveUsers(testData);
//getCountryList(testData);