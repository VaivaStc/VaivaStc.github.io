"use strict";

//funkcija, kuri atspausdina teksta
function printText() {
    console.log("some text")
}

printText(); 

// Parašykite funkciją, kuri išsaugotų a ir b sumą į sum kintamąjį
let a = 10;
let b = 20;
let sum;

function Sudetis() {
    sum = a + b;
    console.log("Suma yra "+sum);
}

Sudetis();
// antras variantas: console.log(sum) ne funkcijoje.

//sumos funkcija su dviem parametrais, kuriuos galime paduoti. Pvz vienas duomuo kintamas, aprasytas, virsuj, kitas paduotas 30. turi priklausomybe nuo isoirnio kintamojo, t.y. newSum. tai ne pure function.
let newSum

function gaukSuma2(skaiciusA, skaiciusB) {
    newSum = skaiciusA + skaiciusB
    console.log("Nauja suma yra:", newSum)
}

gaukSuma2(a, 30);

//pure funkcija. su funkcija return, t.y. prasoma kad ji grazintu. be return funkcija grazins undefiend. 

function gaukSuma2(skaiciusA, skaiciusB) {
    let suma = skaiciusA + skaiciusB
    return suma;
}
let newSuma = gaukSuma2(a, 50);
console.log("newSuma: ", newSuma);

// Parašykite funkciją checkAge(), kuri atspauspintų nepilnametis/pilnametis. Funkcija priima vieną argumentą.
// Pakvieskite funkciją, kad patikrinti:
// checkAge(10);
// checkAge(18);
// checkAge(21);

function CheckAge(OneNumber) {
    let Access = OneNumber >=18? true:false;
    return Access;
}

let Age = CheckAge(10);
console.log("Access:", Age);
/*
function checkAge(age) {
    let result = (age &&age >=18)? "Pilnametis" : "Nepilnametis";
    
    if (!age) return;
    
    if (age >=18) {
        result = "Pilnametis"
    }
    else {
        result = "Nepilnametis"
    }
    console.log(result);
}
*/
// Paraykime funkcija, kuri priimtu viena argumenta - masyva, ir:
// Jei tai ne masyvas - atspausdintu praneima: neteisingas duomenu tipas
// Jei masyvo ilgis 1 - grazintu pirma elementa
// Jei ilgis > uz 1 - grazintu priepaskutini masyvo elementa

let numbers = [1, 2, 3, 4]

function getBeforeLastNumber(numberArray) {
    
    if (!numberArray.splice) {
        console.log("Neteisingas duomenu tipas!");
        return;
    }
    if (numberArray.length === 0) {
        console.log("Tuscias masyvas");
        return;
    } 


    if (numberArray.length === 1) {
        return numberArray[0]
        console.log(numberArray)
    } 
    if (numberArray.length >=2) {
        let beforeLastIndex = numberArray.length -1; 
        return numberArray[beforeLastIndex];

    }
    }

    function getBeforeLastNumber(numberArray) {
        
            if (!numberArray.splice) {
                console.log("neteisingas duomenų tipas");
                return;
            }
            
            if (numberArray.length === 0) {
                console.log("tuscias masyvas");
                return;
            }
            
            if (numberArray.length === 1 ) {
                return numberArray[0];
            } else {
                return numberArray[numberArray.length - 2];
            }
        
        }
//Parašykite funkciją getWordCount, kurios pirmas argumentas ilgas tekstas, antras argumentas - ieškomas žodis.
//Antras argumentas neprivalomas, tada yra grąžimas visų žodžių skaičius.
//Funkcija atspausdina tokį rezultatą:
//"Tekste suradome X žodžius <įvestas žodis>"
//"Tekstas sudarytas ir x žodžių".

function getWordCount(fullText, search) {
    let wordCount;
        if (!search) {
        wordCount = fullText.split(" ").length;
        console.log(`Tekstas sudarytas iš ${wordCount} žodžių`);
    } else {

        let fullTextArray = full.text.split(" ");//sukuriam masyva is teksto elementu
        wordCount = 0;

        for (let index = 0; index < fullTextArray.length; index++) {
            //istrinti nereikalingus simbolius 
            let item = removeSpecialChars(fullTextArray[index]);
            if (item === search) {
                wordCount++;
            } 
        }
        console.log(`tekste suradome ${wordCount} žodžius ${search}`);
    }

}

function removeSpecialChars(text) {
    return text.replace()
}
