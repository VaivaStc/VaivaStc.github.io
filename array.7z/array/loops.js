"use strict";
//while ciklas, skaiciai nuo 1 iki 10.
let number = 1;

while (number <= 10) {
    console.log(number);
    //number = number + 1;
    number++;
}

let number2 = 20;
while (number2 >=1 ) {
    console.log(number2);
    number2--;
}
/*
let skaiciuMasyvas = [];
while (true) {
    let numberInput = prompt("Įveskite skaičių");

    if (numberInput === null) {break ;}

    let RightNumber = parseFloat(numberInput);
    if (isFinite(RightNumber)) {
        skaiciuMasyvas.push(RightNumber);
        //dedam i masyva

    }
    else {
        break;
    }
}

console.log(skaiciuMasyvas)
*/
/*
let skaiciuMasyvas = [];
let sum = 0;

while (true) {
    let numberInput = prompt("Įveskite skaičių");

    if (numberInput === null) {
        console.log("Buvo paspaustas enter. Baigiam įvedimą.");
        break;
    } // Paspaudė ESC
    
    let numberParsed = parseFloat(numberInput);

    if (isFinite(numberParsed)) {
        // dedam i masyva
        skaiciuMasyvas.push(numberParsed);

        // sumuojam
        sum = sum + numberParsed;
    } else {
        // stabdom cikla nes buvo įvestas ne skaičius
        // spausdinam visus rezultatus čia prie break
        let vidurkis = sum / skaiciuMasyvas.length;
        console.log(skaiciuMasyvas);
        console.log(sum);
        console.log(vidurkis);
        break;
    }
}*/

//ciklas kuris atspausdina is eiles visus
let olympicCities = ["Vancouver", "London", "Sochi", "Pyeongchang", "Tokyo", "Beijing", "Paris"];

for (let index = 0; index < olympicCities.length; index++) {
    let miestas = olympicCities[index];
    console.log(index+1 + ".", miestas);
}

for (let index = olympicCities.length - 1; index >=0; index--) {
    let miestas = olympicCities[index];
    console.log(index+1 + ".", miestas);
}

// Atspausdinkite masyve esančia informaciją
// "Jonas yra iš Jonavos, jam 25, el. pašto adresas: jonas@gmail.com"
// Kur nenurodytas miestas rašykite:
// "Jonas nenurodė iš kurio miesto jis yra. Jam 25, el. pašto adresas: jonas@gmail.com"
let vartotojai = [
    ["Jonas", 25, "jonas@gmail.com", 1, "Jonavos"],
    ["Lukas", 18, "lukas@gmail.com", 1, "Kėdainių"],
    ["Petras", 21, "petras@gmail.com", 1],
    ["Danguolė", 23, "danguolė@gmail.com", 0, "Kupiškio"],
    ["Stasys", 17, "petras@gmail.com", 1],
    ["Renata", 20, "renata@gmail.com", 1],
];

for (let index = 0; index < vartotojai.length; index++) {
    let vienas = vartotojai[index];
    document.write(`
    <p>${vienas[0]} yra iš ${vienas[4]}, jam ${vienas[1]}, el. pašto adresas ${vienas[2]}</p>
    `)
}


