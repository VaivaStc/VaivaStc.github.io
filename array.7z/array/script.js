"use strict";
let miestai = ["Vilnius", "Kaunas", "Alytus", "Klaipeda",];
//let miestai = new Array("Vilnius", "Kaunas", "Alytus", "Klaipeda",)

console.log(miestai[0]);
console.log(miestai[3]);

//Sukeisti viena meista su kitu
miestai[2] = "Druskininkai";
console.log(miestai[2]);

//Prideti nauja miesta (nurodant teisinga indeksa)
miestai[5] = "Siauliai"
console.log(miestai);

console.log(miestai.length);

let cities = ["Lima", "Arequipa", "Puno"];
cities[3] = "Mexico";
console.log(cities[0]);
console.log(cities[1]);
console.log(cities[2]);
console.log(cities[3]);
console.log(cities.log);

document.write (`
    <p>1. ${ cities[0] }</p>
    <p>2. ${ cities[1] }</p>
    <p>3. ${ cities[2] }</p>
    <p>4. ${ cities[3] }</p>
    <p>Iš viso: ${cities.length}</p>
`)

//nauju elementu pridejimas i masyva su .push
let skaiciai = [5, 20, 25, 40];
skaiciai.push(9);
console.log(skaiciai);

skaiciai.push(26, 29);
console.log(skaiciai);

//elemento istrynimas is metodo priekio
skaiciai.shift();
console.log(skaiciai);

//ismesto elemento is metodo priekio grazinimas
let pirmas = skaiciai.shift()
console.log(skaiciai);
console.log("Ismestas elementas yra:", pirmas);

//elemento istrynimas is masyvo galo
let paskutinis = skaiciai.pop();
console.log("Ismestas elementas yra:", paskutinis);
console.log(skaiciai);

//prideda elementus is priekio 
skaiciai.unshift(0, 1);
console.log(skaiciai);

//visu masyvu elementu spausdinimas
console.log(skaiciai.toString())

/*
Sukurkite naują masyvą su 5 automobilių markėmis
Pridėkite papildomą elementą masyvo pabaigoje
Pakeiskite priešpaskutinį elementą į kitą automobilio markę
Į naują kintamąjį (pavadinimu pasirinktas) išsaugokite pirmą masyvo elementą, o iš masyvo jį pašalinkite
Atspausdinkite:
"Pasirinktas automobilis: "
"Likę automobiliai: "*/
let cars = ["Saab", "MiniCooper", "Mercedess", "Toyota", "Tesla",];
cars.push("Lexus", "Opel");

cars[cars.length-2] = "Ferrari"; 
let pasirinktas = cars.shift();
console.log("Pasirinktas automobilis:", pasirinktas);
console.log("Like automobiliai", cars);

//trinti is vidurio. Pirmas skaicius - nuo kelinto elemento trinti. Antras skaicius rodo kiek elementu trinti
let stiliai = ["Jazz", "Classical", "Beatbox", "Blues", "Ambient", "Dub"];
stiliai.splice(1, 3);
console.log(stiliai);

//ideti i 2 ir 3 pozicija. nurodai nuo kelintos vietos prideti, 0 - nieko netrini, du pridedi 
stiliai.splice(1, 0, "House music", "IDM");
console.log(stiliai);

//minusiniai indeksai, nuo kur pradeti kazka daryti. nuskao pozicija nuo masyvo galo.
stiliai.splice(-2, 1);
console.log(stiliai);

// Iterpkite "Rio de Janeiro" po "Sochi"
// Pridekite "Athens", "Turin", "Beijing" i sarao prieki
// Isaugokite nauja masyva su paskutiniais 3 miestais i kintamaji:
let olympicCities = ["Vancouver", "London", "Sochi", "Pyeongchang", "Tokyo", "Beijing", "Paris"];
olympicCities.splice(3, 0, "Rio de Janeiro");
olympicCities.splice(0, 0, "Athens", "Turin", "Beijing");
console.log(olympicCities);
//nuo galo trinu tris paksutinius
//let futureOlympicCities = olympicCities.splice(-3, 3);
let futureOlympicCities = olympicCities.slice(-3, 11)
console.log(futureOlympicCities)

//masyvu sujungimas (vienas su kitu)
let arrayA = [1, 2];
let arrayB = ["A", "B"];
let arrayC = arrayA.concat(arrayB);
console.log(arrayC);

//Join. sukuria teksta is masyvo elementu 
let vaisiai = ["Vysnia", "Slyva", "Pomidoras"];
let vaisiaiText = vaisiai.join("-"); //deti kokius nori atskirtukuas., pvz -, arba, ir, . ir ttt
console.log(vaisiaiText);

//Split. 
let tekstas = "Ka man cia parasyti?";
let tekstasArray = tekstas.split(" "); // parasai pagal ka padalinti sakini
console.log(tekstasArray);

//sort surikiuoja pagal abecele
vaisiai.sort();

//teksto eilutej surast simbolis kurioj vietoj
let search = "Tokyo";
let searchResult = olympicCities.indexOf(search);
console.log(searchResult);

//ismeta po seacho true arba false
let searchResult2 = olympicCities.includes(search);
console.log(searchResult2);

