"use strict";

// Forma ir mygtukai
const formElement = document.querySelector("form");
const submitBtn = document.querySelector(".modal .modal-footer > .btn-primary");
const closeBtn = document.querySelector(".modal .modal-footer > .btn-default");

// Formos laukai
const artistInput = document.getElementById("artist");
const albumInput = document.getElementById("album");
const releaseDateInput = document.getElementById("releaseDate");
const imageInput = document.getElementById("image");

const albumListElement = document.querySelector(".album-list");

let allAlbums = [];

const serverName = "http://localhost:3020";

// Patikriname ar turime išsaugotą albumą localStorage
// Jei turime, tada atvaizduojame HTML'e
// if (localStorage.albums) {

    // duomenys iš localStorage
    // allAlbums = JSON.parse(localStorage.albums);


    // duomenys iš serverio
    fetch(serverName +"/albums")
        .then(function(response){
            response.json()
                .then(function(albums) {
                    // Išsisaugom visus albumus
                    allAlbums = albums;

                    // Spausdinam į HTML
                    renderAlbums(albums);
                });
        })

// }


// Registruojam mygtuko paspausimą ant "Pridėti"
submitBtn.addEventListener("click", saveAlbum);

// Funkcija, kuri saugo albumą
function saveAlbum() {
    let imageName = imageInput.files[0] ? imageInput.files[0].name : "";

    let album = {
        "artist": artistInput.value,
        "album": albumInput.value,
        "releaseDate": releaseDateInput.value,
        "image": imageName
    };

    

    // Išsaugome albumą į localStorage

    // Saugom į serverį
    fetch(serverName +"/albums",{
            method: "POST",
            headers: {'content-type': 'application/json'},
            body: JSON.stringify(album)
        }).then(function(response){
            response.json()
            .then(function(result){
                album.id = result.id;
                //issaugojam albuma i bendra sarasa
                all.Albums.push(album); 
                //atvaizduojam albuma HTML'e
                renderAlbums(allAlbums);  
                console.log("Išsaugojo", response);
            }) 
    })  

}

function renderAlbums(albums) {
    let resultHtml = '';

    // Išsisaugom kiekvieno albumo html
    albums.forEach(function(album) {
        resultHtml += `
            <div class="album clearfix panel panel-default" data-id="${album.id}">
                <div class="panel-body">
                    <img src="upload/${album.image}" alt="" class="pull-left" width="150">
                    <h3>${album.artist} - ${album.album}</h3>
                    Date: ${album.releaseDate}
                    <button class="btn-remove-album btn btn-danger pull-right" onclick="deleteAlbum(${album.id})">Ištrinti</button>
                </div>
            </div>
        `;
    });


    // Viena operacija - įrašau visą rezultatą
    albumListElement.innerHTML = resultHtml;
}


function deleteAlbum(id) {
    
    //Trinam is serverio
    fetch(serverName +"/albums/"+ id, {
        method: "DELETE",
    }).then(function(response){
        console.log("Albumas ištrintas", response);
    })

    //trinam is HTML
    let albumToRemove = document.querySelector(`[data-id="${id}"]`).remove(); 

}


// //filtras 
// let filtered = allAlbums.filter(function(album) {
//     return true;
// });

