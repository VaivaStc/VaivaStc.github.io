"use strict";
//sukurkime nauja vue.js aplikacija
//susiekima ja su dom naudodami ID. aopp visas appsas. new view sukuria aplikacija, jai reikia paduoti objekta, kuriame bus aplikacijos kodas. ka reikia susieti su html. el per ji susiejamos aplikacijos. t.y. konkretus elementas bus apikacija. po kablelio reikia duomenu. jie saugomi data property. data yr aobjektas. {{}} teksto interpoliacija, kuria nurodo i html
let app = new Vue({
    el: "#app",
    data: {
        title: "Mano užduotys",
        tasks: [
            {name: "Išmokti JavaScript", isChecked: false},
            {name: "Aplikuoti i praktika", isChecked: false}, 
        ],
        newTaskInput: ""
    },
    methods: {
        addNew: function () {
            if (this.newTaskInput !== "") {
                this.tasks.push({name: this.newTaskInput, isChecked: false});
                this.newTaskInput = ''
            }
        }
    },
    computed: {
        finishedTasks: function() {
            return this.tasks.filter(function(task) {
                return task.isChecked;
            }).length;

        }

    }
});

/*
pasidaria filtra
patikrina masyve, ar yra pazymetu checkboxu.
var masyvas = [
    {name: "Išmokti JavaScript", isChecked: true},
    {name: "Aplikuoti i praktika", isChecked: false},
]
//grazina tru is isCHecked, t.y. tos, kurios pazymetos
function getCheckedCount() {
    let filtered = masyvas.filter(function(task) {
        return task.isChecked;
    });

    return filtered.length;
}


*/
