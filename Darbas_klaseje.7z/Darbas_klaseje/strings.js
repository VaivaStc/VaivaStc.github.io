let vardas = "Vaiva";
let pirmaRaide = [0];

console.log(pirmaRaide);

let vardoIlgis = vardas.length;
let paskutineRaide = vardas[vardoIlgis - 1];
console.log ("paskutine raide", paskutineRaide);

//Paieska
let pastraipa = "Daug teksto";
let paieska = "i";

console.log("Ieskome raides", paieska);
console.log("Jos indeksas zodyje yra", pastraipa.indexOf(paieska));

//Didziosios raides
console.log(vardas.toLocaleUpperCase())