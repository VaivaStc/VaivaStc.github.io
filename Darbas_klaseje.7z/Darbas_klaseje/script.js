/* 
let vardas = "Andrius";
let pavarde = "\"Stonys\"";
let isAlive = 10 < 100;
const GIMIMODATA = "1985-04-31";

let pilnasVardas = vardas + pavarde;
pilnasVardas = true;

document.write(isAlive);

// Patikrinsim tipą
let test = 9 + Number("9"); // tipas ?
console.log(test);
console.log(typeof test);
*/

const DARBINGI_ZMONES = 1761463;
const LIETUVOS_BIUDZETAS_2017 = 8487300000;


let userInput = prompt("Įveskite bazinio užmokesčio dydį, €");
bazinisUzmokestis = parseFloat (userInput);

if (!bazinisUzmokestis) {
    alert("Skaičius įvestas neteisingai");
} else {
    console.log ("Daugiau už 480");
}

let bazinisUzmokestisZmogui = bazinisUzmokestis * 12;
let bazinisUzmokestisVisiems = bazinisUzmokestisZmogui * DARBINGI_ZMONES;
let biudzetoDalis = bazinisUzmokestisVisiems * 100 / LIETUVOS_BIUDZETAS_2017;

if (bazinisUzmokestisVisiems > LIETUVOS_BIUDZETAS_2017) {
    alert ("Nėra tiek pinigų");
} else {
    if (bazinisUzmokestisVisiems >= LIETUVOS_BIUDZETAS_2017/2) {
        alert ("Išmokos viršija 50% Lietuvos biudžeto");
    }
    document.write(`
    <p>Darbingi žmonės Lietuvoje: ${ DARBINGI_ZMONES } </p>
    <p>Bazinis užmokestis žmogui: ${ bazinisUzmokestis }</p>
    <p>Lietuvos biudžetas: ${ LIETUVOS_BIUDZETAS_2017}  mln. €</p>
    <p>Išmokos sudarytų <strong> ${ biudzetoDalis.toFixed(2) } %</strong> Lietuvos biudžeto.</p>
    `);
 
}


/*let A = prompt("Įveskite pirmą skaičių");
let B = prompt("Įveskite antrą skaičių"); 

let Sum = +A + +B;
let Min = A - B;
let Del = A / B;


document.write(`
<p>A + B = ${Sum}</p>
<p>A - B = ${Min}</p>
<p>A / B = ${Del}</p>
<p>ar A daugiau už B: ${A > B}</p>
<p> A reikšmės tipas: ${ typeof A }</p>
`)
*/



