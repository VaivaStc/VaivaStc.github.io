"use strict";
//1 užduotis
function getEmailList(personList) {
    let emails = [];

        for(let index = 0; index < personList.length; index++) {
        let person = personList[index];
        emails.push(person.email)};
    return emails
}

document.write("El. pašto adresai: " + getEmailList(MOCK_DATA));

//2 užduotis
function getMaleUsers(personList) {
    let males = [];
    for(let index = 0; index < personList.length; index++){
        let person = personList[index];
    if(person.gender === "Male") {
        males.push(`${person.first_name} ${person.last_name}`)
    }
    }
    return males;
}
document.write("<p>Vartotojai vyrai:" + " " + getMaleUsers(MOCK_DATA));

//3 užduotis Parašykite funkciją, kurią pakvietus ir padavus MOCK_DATA duomenis bei tekstą "male" arba "female", mums grąžintų vyrų arba moterų skaičių iš duomenų. Pvz.:
// grąžina vyrų skaičių

/*function genderCount(personList) {
    let genderMale = [];
    let genderFemale = [];
    for(let index=0; index < personList.length; index++) {
        let person = personList[index];
        if(person.gender === "Male") {
            genderMale.push(`${person.gender}`);
            console.log(genderMale.length);
        } else {
            genderFemale.push(`${person.gender}`);
            console.log(genderFemale.length);
        }

    }
    return genderMale.length; 
    return genderFemale.length;

}
document.write("<p>Vartotojų vyrų skaičius:" + " " + genderCount(MOCK_DATA));
document.write("<p>Vartotojų moterų skaičius:" + " " + genderFemale(MOCK_DATA));*/

let maleCount = countPeople(MOCK_DATA, "male");
let femaleCount = countPeople(MOCK_DATA, "Female");


